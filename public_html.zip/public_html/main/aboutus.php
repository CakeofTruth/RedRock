<?php
	$pagetitle = "About Us";
	include ($_SERVER ["DOCUMENT_ROOT"] . '/main/header.php');
?>

	<?php include 'menu.php' ?>
	<div class="description"><h2>About Us</h2></div>
	<div class="content">
		<p> Red Rock Telecommunications is the first company in the world to combine the power of Metaswitch with the voice 
		 and video features of Avaya.  This allows us to be the sole provider of an all IP based communication solution. Red 
		 Rock delivers reliable high quality hosted PBX, SIP Trunking, voice to text capabilities, mobile device integration,
		 and much more. </p>
	</div>	
	
<?php include $root . '/main/footer.php'?>