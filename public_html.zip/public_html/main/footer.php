<div id="resources" style="text-align: center;">
	<a href="<?php $root ?>/accounts/login.php"><span style="color: black; position: fixed; bottom: 25pt;">Resources</span></a>
</div>
</body>
</html>