<html>
	<head>
	<title> Red Rock Ordering System </title>
	<style>
	h1 {
		font-size: 50px; 
		text-align: center;
	}
	table {
		margin: 0 auto;
	}
	table, th, td {
		border: 1px solid black;
		border-collapse: collapse;
	}
	table {
		width: 70%;
	}
	th {
    height: 20px;
	}
	tr:hover {
	background-color: #ff8080
	}
	tr:nth-child(even) {
	background-color: #B3C6FF
	}
	</style>
	</head>
	
	<body>
	<img src= " C:\Users\Rae\Pictures\Red Rock Logo.jpg" style= "float:left;"/>
	<h1> Red Rock Ordering System </h1>
		<form>
		<table>
			<thead>
				<tr>
					<th> Ammount </th>
					<th> Category </th>
					<th> USOC </th>
					<th> Description </th>
					<th> MRC </th>
					<th> NRC </th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WNIPLD </td>
					<td> IP Station Line- w/LD </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WOIPL </td>
					<td> IP Station Line National- Tier 1 w/LD </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WNIP10 </td>
					<td> IP Station Line w/LD </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WNIPC </td>
					<td> IP Line w/ LD (Volume Discount Tier) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> RVTN </td>
					<td> Virtual Telephone Number </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WNIPC </td>
					<td> IP Station Line w/ LD (Volume Discount Tier) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> RDID </td>
					<td> DID Number </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> RBIP </td>
					<td> Analog IP Line (ATA) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WATAL </td>
					<td> ATA Analog Line w/ LD </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WIOS </td>
					<td> Light Use Seat (No VM, no LD, no Portal) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WNIP11 </td>
					<td> IP Line w/ LD (Volume Discount Tier) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WNIPL9 </td>
					<td> IP Station Line w/ LD </td>
					<td> $9.00 </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WNIPL8 </td>
					<td> IP Station Line w/ LD </td>
					<td> $8.00 </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WAV </td>
					<td> Hosted Seats/ Avaya </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WAVF </td>
					<td> Hosted Seats/ Avaya + Features </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WAVCCL </td>
					<td> Avaya Contact Center Lite </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Hosted Seats/IP Lines </td>
					<td> WAVCCF </td>
					<td> Avaya Contact Center Full Suite </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> W911 </td>
					<td> E911 National Service (per Number) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> W911A </td>
					<td> Additional 911 Addresses </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> TFNUM </td>
					<td> Toll Free Number </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WDIDC </td>
					<td> DID Number National </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> RAAEV </td>
					<td> Premium Auto Attendant </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> RMOHCV </td>
					<td> Music on Hold- Custom </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> RRECSV </td>
					<td> Call Recording- Per Seat </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> RACDPV </td>
					<td> ACD Premium </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> RACDSV </td>
					<td> Hosted Call Center- Supervisor Seat </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> RACDPV </td>
					<td> ACD Premium</td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Miscellaneous Services </td>
					<td> WACMD </td>
					<td> Accession Desktop and Mobile </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Miscellaneous Services </td>
					<td> WAAE </td>
					<td> Premium Auto Attendant </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Miscellaneous Services </td>
					<td> WCCS </td>
					<td> Audio Conferencing (.03 per mou) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Miscellaneous Services </td>
					<td> WAUMP </td>
					<td> Audio Conferencing Moderator and Participant Code </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WICMI </td>
					<td> Incoming Call Manager (ICM)(Per Seat) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Miscellaneous Services </td>
					<td> WACDP </td>
					<td> ACD Premium- Per Seat </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WACDB </td>
					<td> ACD Basic- Per Seat </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WACDS </td>
					<td> ACD Supervisor </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> LNP </td>
					<td> Local Number Porting (For #'s in Addition to Seats) 0-100 </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> LNP 2 </td>
					<td> Local Number Porting (For #'s in Addition to Seats) 100+ </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WLDP2 </td>
					<td> Long Distance Package- 50,000 Minutes </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WVMB </td>
					<td> Voicemail (A la Carte) </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WLDP1 </td>
					<td> Long Distance Package- 100,000 Minutes </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> RTFNUM </td>
					<td> Toll Free Number </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WFL </td>
					<td> DA Listing/ White Page- Additional Listing </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Miscellaneous Services </td>
					<td> WEA </td>
					<td> Easy Attendant </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td>  <input type="text">  </td>
					<td> Miscellaneous Services </td>
					<td> WABR </td>
					<td> Accession Branding- One Time </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td> <input type="text"> </td>
					<td> Miscellaneous Services </td>
					<td> WTFP1 </td>
					<td> Toll Free Package- 100,000 Minutes </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td> <input type="text"> </td>
					<td> SIP Trunking </td>
					<td> RITNLV </td>
					<td> SIP Trunk (National Tier 1) w/LD </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
				<tr>
					<td> <input type="text">  </td>
					<td> SIP Trunking </td>
					<td> RITSL </td>
					<td> SIP Trunk w/ 500 LD </td>
					<td> $#.## </td>
					<td> $#.## </td>
				</tr>
			</table>
			<input type="submit" value="Submit">
		</form>
	</body>
</html>