<!DOCTYPE html>
<html>
<head>
<title>Forgot Your Password?</title>
</head>
<body>
	<form action="change.php" method="POST">
	E-mail Address: <input type="text" name="emailAddress"/><input type="submit" name="ForgotPassword" value="Request Reset" />
	</form>