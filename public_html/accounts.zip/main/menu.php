<div id="menu">
	<ul>
		<li><a href="<?php $root ?>/index.php"><font color="#21B6A8">Home</font></a></li>
		<li><a href="<?php $root ?>/main/aboutus.php"><font color="#21B6A8">About Us</font></a>
		<li><a href="http://support.redrocktelecom.com"><font color="#21B6A8">Customer Service</font></a></li>
		<li><a href="<?php $root ?>/main/contactus.php"><font color="#21B6A8">Contact Us</font></a></li>
	</ul>
</div>
