<!DOCTYPE html>
<html>
<head>
<style type="text/css">
		body{ background-color: #ffffff; background-image: url("assets/images/sandtexture5.png"); background-repeat: repeat; background-position: top left; 
		background-attachment: Scroll;}
</style>
<script type="text/javascript" src="/js/jquery/jquery.js"></script>
</head>
<body>
<?php
	$pagetitle = "Our Team";
	include ($_SERVER ["DOCUMENT_ROOT"] . '/main/header.php');
?>
<div id="primary" class="sidebar-no">
	<div class="container group">
		<div class="row">
			<div id="content-page" class="span12 content group">
				<div class="page type-page status-publish group">
					<div class="team-slider wrapper team-rounded margin-top margin-bottom">
						<div class="list_carousel">
							<div class="caroufredsel_wrapper" style="display:block; text-align: start; 
							float:none; position: relative; top: auto; right: auto; bottom: auto; left: auto;/
							z-index: auto; width: 1170px; height: 422px; margin: 0px; overflow: hidden;">
								<ul class="team-slides" style="text-align: left; float: none; position:
								absolute; top: 0px; right: auto; bottom: auto; left: 3px; margin: 0px; width: 3886px;
								height: 422px; z-index: auto;">
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/brenda.jpg" alt="Brenda Beall">
										</div>
										<h6> Brenda Beall </h6>
										<p> Here is some information about Brenda that we will fill in later."</p>
										<div class= "meta">
											<p>
												<strong> Sales </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/neil.jpg" alt="Neil Wilson">
										</div>
										<h6> Neil Wilson </h6>
										<p>
											Here is some information about Neil that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Sales </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/greg.jpg" alt="Greg Paduganan">
										</div>
										<h6> Greg Paduganan </h6>
										<p>
											Here is some information about Greg that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Adminstrative </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/chris.jpg" alt="Christopher Pleiter">
										</div>
										<h6> Christopher Pleiter </h6>
										<p>
											Here is some information about Christopher/Anna that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Operations </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/rae.jpg" alt="Rae LeClaire">
										</div>
										<h6> Rae LeClaire </h6>
										<p>
											Here is some information about Rae that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Operations </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/kevin.png" alt="Kevin Stalker">
										</div>
										<h6> Kevin Stalker </h6>
										<p>
											Here is some information about Kevin that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Operations </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/lance.jpg" alt="Lance McGee">
										</div>
										<h6> Lance McGee </h6>
										<p>
											Here is some information about Lance that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Operations </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/shane.png" alt="Shane Gregory">
										</div>
										<h6> Shane Gregory </h6>
										<p>
											Here is some information about Shane that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Operations </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>
												<img src="/assets/images/tom.png" alt="Tom LeClaire">
										</div>
										<h6> Tom LeClaire </h6>
										<p>
											Here is some information about Tom that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Administrative </strong>
											</p>
										</div>
									</li>
									<li style="height:422px; margin-right:12px;">
										<div class="team-circle bwWrapper">
											<canvas width="130" height="130" style="position: absolute; top: 0px; left: 0px; width: 130px;
											height: 130px; display: block;"></canvas>>
												<img src="/assets/images/jack.png" alt="Jack Pleiter">
										</div>
										<h6> Jack Pleiter </h6>
										<p>
											Here is some information about Jack that we will fill in later."
										</p>
										<div class= "meta">
											<p>
												<strong> Administrative </strong>
											</p>
										</div>
									</li>
								</ul>
							</div>
						</div>
						<div class="clearfix">
						</div>
						<div class="nav">
							<a id="team-slider-prev" class="prev" href="#" style="display: block;"></a>
							<a id="team-slider-next" class="next" href="#" style="display:block;"></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
					<script type="text/javascript">
								jQuery(function ($) {
									var maxHeight = 0;
									
									$('.team-slides li').each(function () {
										if ($(this).height() > maxHeight) {
											maxHeight = $(this).height();
										}
									});
									$('.team-slides li').height(maxHeight + 20);
									$('.team-slides').imagesLoaded(function () {
										$('.team-slides').carouFredSel({
											auto: true,
											width: '100%',
											prev: '#team-slider-prev',
											next: '#team-slider-next',
											swipe: {
												onTouch: true
											},
											scroll: {
												items:1,
												duration: 500
											}
										});
									});
									$('.bwWrapper').BlackAndWhite({
										hoverEffect: true,
										webworkerPath: false,
										responsive: true,
										speed: {
											fadeIn: 200
											fadeOut: 300
										}
									});
								});
							</script>
						</div>
<?php include $root . '/main/footer.php'?>
<script type="text/javascript src="/js/comment-reply.min.js"></script>
<script type="text/javascript" src="/js/underscore.min.js"></script>
<script type="text/javascript" src="/js/jquery/jquery.masonry.min.js"></script>
<script type="text/javascript" src="/js/jquery.easing.js"></script>
<script type="text/javascript" src="/js/hoverIntent.min.js"></script>
<script type="text/javascript" src="/js/jQuery.BlackAndWhite.js"></script>
<script type="text/javascript" src="/js/jquery.carouFredSel-6.1.0-packed.js"></script>
<script type="text/javascript" src="/js/jquery.colorbox-min.js"></script>
<script type="text/javascript" src="/js/media-upload.min.js"></script>
<script type="text/javascript" src="/js/jquery.clickout.min.js"></script>
<script type="text/javascript" src="/js/responsive.js"></script>
<script type="text/javascript" src="/js/mobilemenu.js"></script>
<script type="text/javascript" src="/js/jquery.superfish.js"></script>
<script type="text/javascript" src="/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/js/contact.js"></script>
<script type="text/javascript" src="/js/jquery.tipsy.js"></script>
<script type="text/javascript" src="/js/jquery.cycle.min.js"></script>
<script type="text/javascript" src="/js/shortcodes.js"></script>
<script type="text/javascript" src="js/jquery.cusstom.js"></script>
</body>
</html>
								